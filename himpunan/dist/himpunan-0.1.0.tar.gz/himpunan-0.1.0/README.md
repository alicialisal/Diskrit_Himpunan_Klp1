# Himpunan

Himpunan adalah library Python sederhana untuk operasi pada himpunan.

## Instalasi
```bash
pip install himpunan
